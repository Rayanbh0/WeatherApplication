const colorBg1 = 0xFF7363C5;
const colorBg2 = 0xFF935CA9;
const colorBg3 = 0xFFBDA3C8;